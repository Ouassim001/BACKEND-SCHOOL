<link rel="stylesheet" type="text/css" href="styles.css">
</main>
    <footer>
        <!-- Voeg je naam en de actuele datum toe -->
        &copy; Ouassim Mrabti <?php echo date('Y.m.d'); ?>
    </footer>
</body>
</html>
