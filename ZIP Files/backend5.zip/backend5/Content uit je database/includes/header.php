<!DOCTYPE html>
<html>
<head>
    <title>Mijn Website</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
    <!-- Voeg eventuele CSS-bestanden en andere headers toe -->
</head>
<body>
    <header>
        <!-- Voeg je navigatiemenu toe -->
        <nav>
            <ul>
                <li><a href="index.php?page=Onderwerp1">Onderwerp 1</a></li>
                <li><a href="index.php?page=Onderwerp2">Onderwerp 2</a></li>
                <li><a href="index.php?page=Onderwerp3">Onderwerp 3</a></li>
            </ul>
        </nav>
    </header>
    <main>
